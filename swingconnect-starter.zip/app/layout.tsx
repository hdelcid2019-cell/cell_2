import "./globals.css"
import Nav from "@/components/Nav"
import { ClerkProvider } from "@clerk/nextjs"

export const metadata = {
  title: "SwingConnect",
  description: "Discover, connect, and chat—messaging unlocked with subscription."
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <ClerkProvider>
      <html lang="en">
        <body>
          <Nav />
          <main className="container pb-20">{children}</main>
        </body>
      </html>
    </ClerkProvider>
  )
}
