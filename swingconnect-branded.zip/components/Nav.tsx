import Link from "next/link"
import Image from "next/image"

export default function Nav() {
  return (
    <nav className="container py-4 flex items-center justify-between">
      <Link href="/" className="flex items-center gap-2">
        <Image src="/logo.svg" alt="logo" width={28} height={28} />
        <span className="text-lg font-semibold">SwingConnect</span>
      </Link>
      <div className="flex gap-3">
        <Link className="btn" href="/discover">Discover</Link>
        <Link className="btn" href="/billing">Plans</Link>
      </div>
    </nav>
  )
}
