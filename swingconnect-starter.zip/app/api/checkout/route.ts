import Stripe from "stripe"

export async function POST(req: Request) {
  const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-06-20" })
  const { plan } = await req.json()
  const priceMap: Record<string, string> = {
    basic: process.env.NEXT_PUBLIC_STRIPE_PRICE_BASIC!,
    plus: process.env.NEXT_PUBLIC_STRIPE_PRICE_PLUS!,
    vip: process.env.NEXT_PUBLIC_STRIPE_PRICE_VIP!,
  }
  const price = priceMap[plan]
  if (!price) return Response.json({ error: "Unknown plan" }, { status: 400 })
  const session = await stripe.checkout.sessions.create({
    mode: "subscription",
    line_items: [{ price, quantity: 1 }],
    success_url: process.env.NEXT_PUBLIC_SITE_URL ? `${process.env.NEXT_PUBLIC_SITE_URL}/billing?ok=1` : "http://localhost:3000/billing?ok=1",
    cancel_url: process.env.NEXT_PUBLIC_SITE_URL ? `${process.env.NEXT_PUBLIC_SITE_URL}/billing?canceled=1` : "http://localhost:3000/billing?canceled=1",
  })
  return Response.json({ url: session.url })
}
