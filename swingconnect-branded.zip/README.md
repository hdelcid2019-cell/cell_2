# SwingConnect (Branded Starter, no Clerk)

Local preview-ready Next.js template with subscription-gated chat UI pieces and a logo slot.

## Local quick start
1) npm install --legacy-peer-deps
2) npx prisma db push
3) npm run dev → open http://localhost:3000

## Notes
- Local DB: SQLite file `dev.db`.
- Production: switch the Prisma datasource to PostgreSQL and set `DATABASE_URL`.
- Billing page uses a placeholder checkout in preview mode.
