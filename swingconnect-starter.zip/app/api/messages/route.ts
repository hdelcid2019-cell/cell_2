import { auth } from "@clerk/nextjs"
import { prisma } from "@/lib/prisma"

export async function POST(req: Request) {
  const { userId } = auth()
  if (!userId) return Response.json({ error: "Unauthorized" }, { status: 401 })
  const { toId, body } = await req.json()
  const sub = await prisma.subscription.findUnique({ where: { userId } })
  if (!sub || sub.status !== "active") return Response.json({ paywall: true }, { status: 402 })
  const msg = await prisma.message.create({ data: { fromId: userId, toId, body } })
  return Response.json(msg)
}
