import { clerkMiddleware, getAuth } from "@clerk/nextjs/server"
import { isActiveSubscriber } from "@/lib/subscriptions"

export default clerkMiddleware(async (auth, req) => {
  const url = new URL(req.url)
  if (url.pathname.startsWith("/api/messages")) {
    const { userId } = getAuth(req as any)
    if (!userId) return new Response("Unauthorized", { status: 401 })
    const ok = await isActiveSubscriber(userId)
    if (!ok) return new Response(JSON.stringify({ paywall: true }), { status: 402 })
  }
  return
})

export const config = {
  matcher: ["/((?!_next|.*\..*).*)"],
}
